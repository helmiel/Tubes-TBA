Source code tugas besar mata kuliah teori bahasa automata

**Kelompok: 1**

Anggota Kelompok:
1. Fikri Fauzi (1301223043)
2. Helmi Efendi Lubis (1301223338)
